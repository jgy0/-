# Task1.1
import pandas as pd
import numpy as np

SalesData = pd.read_excel('./非洲通讯产品销售数据.xlsx', sheet_name='SalesData')

SalespersonData = pd.read_excel('./非洲通讯产品销售数据.xlsx', sheet_name='SalespersonData')

SalesData['年份'] = pd.to_datetime(SalesData['日期']).dt.year

new_sale = SalesData.groupby(['地区','国家','年份','服务分类'])['销售额', '利润'].sum()

new_sale = pd.DataFrame(new_sale)

new_sale_1 = new_sale.reset_index()

new_sale_1[['国家','地区','服务分类','销售额','利润']].to_csv("F:\\1.2.csv",encoding="gbk",index=None)

country_list = np.unique(new_sale_1['国家'])

service_list = list(np.unique(SalesData['服务分类']))

def country(name):
    return new_sale_1.loc[new_sale_1['国家'] == name]

def year(data, year):
    return data.loc[data['年份'] == year]

def service(data, service):
    return data.loc[data['服务分类'] == service]

def complete(name, service_):
    data = country(name)
    dict1={}
    year1 = year(data, 2017)
    year2 = year(data, 2018)
    year3 = year(data, 2019)
    year4 = year(data, 2020)
    if service_ in list(year1['服务分类']) and service_ in list(year2['服务分类']):
        dict1["2018_"+service_] = (list(service(year2, service_)['销售额'])[0] - list(service(year1, service_)['销售额'])[0])/list(service(year1, service_)['销售额'])[0]
    if service_ in list(year2['服务分类']) and service_ in list(year3['服务分类']):
        dict1["2019_"+service_] = (list(service(year3, service_)['销售额'])[0] - list(service(year2, service_)['销售额'])[0])/list(service(year2, service_)['销售额'])[0]
    if service_ in list(year3['服务分类']) and service_ in list(year4['服务分类']):
        dict1["2020_"+service_] = (list(service(year4, service_)['销售额'])[0] - list(service(year3, service_)['销售额'])[0])/list(service(year3, service_)['销售额'])[0]
    return dict1

def complete1(name, service_):
    data = country(name)
    dict1={}
    year1 = year(data, 2017)
    year2 = year(data, 2018)
    year3 = year(data, 2019)
    year4 = year(data, 2020)
    if service_ in list(year1['服务分类']) and service_ in list(year2['服务分类']) and list(service(year1, service_)['利润'])[0]!=0:
        dict1["2018_"+service_] = (list(service(year2, service_)['利润'])[0] - list(service(year1, service_)['利润'])[0])/list(service(year1, service_)['利润'])[0]
    if service_ in list(year2['服务分类']) and service_ in list(year3['服务分类']) and list(service(year2, service_)['利润'])[0]!=0:
        dict1["2019_"+service_] = (list(service(year3, service_)['利润'])[0] - list(service(year2, service_)['利润'])[0])/list(service(year2, service_)['利润'])[0]
    if service_ in list(year3['服务分类']) and service_ in list(year4['服务分类']) and list(service(year3, service_)['利润'])[0]!=0:
        dict1["2020_"+service_] = (list(service(year4, service_)['利润'])[0] - list(service(year3, service_)['利润'])[0])/list(service(year3, service_)['利润'])[0]
    return dict1

def concat_1():
    for j in range(len(service_list)):
        if j == 0:
            for i in range(len(country_list)):
                if i == 0:
                    con1 = pd.DataFrame(complete(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                    con1 = pd.concat([con1,data])
        if j == 1:
            for i in range(len(country_list)):
                if i == 0:
                    con2 = pd.DataFrame(complete(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                    con2 = pd.concat([con2,data])
        if j == 2:
            for i in range(len(country_list)):
                if i == 0:
                    con3 = pd.DataFrame(complete(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                    con3 = pd.concat([con3,data])
    return con1,con2,con3

def concat_2():
    for j in range(len(service_list)):
        if j == 0:
            for i in range(len(country_list)):
                if i == 0:
                    con1 = pd.DataFrame(complete1(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                else:
                    data = pd.DataFrame(complete1(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                    con1 = pd.concat([con1,data])
        if j == 1:
            for i in range(len(country_list)):
                if i == 0:
                    con2 = pd.DataFrame(complete1(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                else:
                    data = pd.DataFrame(complete1(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                    con2 = pd.concat([con2,data])
        if j == 2:
            for i in range(len(country_list)):
                if i == 0:
                    con3 = pd.DataFrame(complete1(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                else:
                    data = pd.DataFrame(complete1(country_list[i],service_list[j]),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                    con3 = pd.concat([con3,data])
    return con1,con2,con3

con1.to_csv('F:\\Commercial销售额同比增长率.csv',encoding="gbk")
con2.to_csv('F:\\Public销售额同比增长率.csv',encoding="gbk")
con3.to_csv('F:\\Residential销售额同比增长率.csv',encoding="gbk")

new_dt1 = pd.concat([con1,con2],axis=1)
new_dt1 = pd.concat([new_dt1,con3], axis=1)
new_dt1.to_csv('F:\\销售额.csv', encoding="gbk")

con1_1,con2_2,con3_3=concat_2()

con1_1.to_csv('F:\\Commercial利润同比增长率.csv',encoding="gbk")
con2_2.to_csv('F:\\Public利润同比增长率.csv',encoding="gbk")
con3_3.to_csv('F:\\Residential利润同比增长率.csv',encoding="gbk")


new_dt2 = pd.concat([con1_1,con2_2],axis=1)
new_dt2 = pd.concat([new_dt2,con3_3], axis=1)
new_dt2.to_csv('F:\\利润.csv', encoding="gbk")

# Task1.2
import pandas as pd
import numpy as np

SalesData = pd.read_excel('./非洲通讯产品销售数据.xlsx', sheet_name='SalesData')

SalespersonData = pd.read_excel('./非洲通讯产品销售数据.xlsx', sheet_name='SalespersonData')

SalesData['年份'] = pd.to_datetime(SalesData['日期']).dt.year

new_sale = SalesData.groupby(['地区','国家','年份','服务分类'])['销售额', '利润'].sum()

new_sale_1[['国家','地区','服务分类','销售额','利润']].to_csv("F:\\1.2.csv",encoding="gbk",index=None)

import pandas as pd
import pyecharts.options as opts
from pyecharts.charts import Line
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

def task1_3():
    data = pd.read_excel(r"E:\2021泰迪杯A\非洲通讯产品销售数据.xlsx", sheet_name='SalespersonData')
    data['合同总数'] = data['销售合同']/data['成交率']
    # print(data['成交总数'])
    # print(data)
    # print(data.info())
    # print(data.head())
    # print(data['销售经理'].drop_duplicates().tolist())
    person = data['销售经理'].drop_duplicates().tolist()
    # print(len(person))
    List = []
    for name in person:
        # print(name)
        data_name = data[data['销售经理'] == name]
        x = data_name['销售合同'].sum()
        y = data_name['合同总数'].sum()
        z = x/y
        List.append([name, x, y, z])
        # print(x, y, z)
    # 名字:成交总数，总成交率
    print('\n', List)
    for i in List:
        print(i)


def task1_4():
    data_excel = pd.read_excel(r"E:\2021泰迪杯A\非洲通讯产品销售数据.xlsx", sheet_name='SalesData')
    data_excel['日期'] = pd.to_datetime(data_excel['日期'], format='%Y/%m/%d')
    data_excel['年份'] = pd.to_datetime(data_excel['日期']).dt.year
    data_excel['月份'] = pd.to_datetime(data_excel['日期']).dt.month
    print(data_excel)

    # 国家
    def Con():
        # data_con = data_excel['国家'].drop_duplicates().tolist()
        # print(len(data_con))
        #
        # List = []
        # for name in data_con:
        #     data = data_excel[data_excel['国家'] == name]
        #     data = data.groupby(['年份', '月份', '国家'])['销售额'].sum().reset_index()
        #     print(data)
        #
        #     x = data['年份'].tolist()
        #     # print(x)
        #     y = data['月份'].tolist()
        #     # print(y)
        #     data_x = []
        #     for i in range(len(x)):
        #         data_x.append(str(x[i]) + '-' + str(y[i]))
        #     print(data_x)
        #
        #     data_y = data['销售额'].tolist()
        #     print(data_y)
        #
        #
        #     # (
        #     #     Line()
        #     #         .set_global_opts(
        #     #         tooltip_opts=opts.TooltipOpts(is_show=False),
        #     #         xaxis_opts=opts.AxisOpts(type_="category"),
        #     #         yaxis_opts=opts.AxisOpts(
        #     #             type_="value",
        #     #             axistick_opts=opts.AxisTickOpts(is_show=True),
        #     #             splitline_opts=opts.SplitLineOpts(is_show=True),
        #     #         ),
        #     #     )
        #     #         .add_xaxis(xaxis_data=data_x)
        #     #         .add_yaxis(
        #     #         series_name="",
        #     #         y_axis=data_y,
        #     #         symbol="emptyCircle",
        #     #         is_symbol_show=True,
        #     #         label_opts=opts.LabelOpts(is_show=False),
        #     #     )
        #     #         .render("{}_line_chart.html".format(name))
        #     # )
        data_con = data_excel['国家'].drop_duplicates().tolist()
        # print(data_con)
        List = []
        for con in data_con:
            data = data_excel[data_excel['国家'] == con]

            data = data.groupby(['年份', '月份','国家'])['销售额'].sum().reset_index()
            print(data)

            x = data['年份'].tolist()
            y = data['月份'].tolist()
            data_x = []
            for i in range(len(x)):
                data_x.append((str(x[i]) + '-' + str(y[i]) + '-' + str(1)).strip())
            data['新日期'] = data_x
            data['timestamp'] = pd.to_datetime(data['新日期'])
            data.index = data['timestamp']
            # print(data)

            train = data[data['年份'] <= 2020]
            train['timestamp'] = pd.to_datetime(data['新日期'])
            train.index = train['timestamp']
            import statsmodels.api as sm

            fit1 = sm.tsa.statespace.SARIMAX(train['销售额'], order=(11, 1, 2), enforce_stationarity=False,
                                             enforce_invertibility=False).fit()
            ans = fit1.forecast(3).tolist()
            print(sum(ans))
            List.append([con, sum(ans)])
        print(List)
        for i in List:
            print(i)
        data_csv = pd.DataFrame(List,columns=(['国家', '预测销售额']))
        print(data_csv.sort_values(['预测销售额'], ascending=False))

    # 地区
    def Area():
        data_area = data_excel['地区'].drop_duplicates().tolist()
        print(data_area)
        List = []
        for area in data_area:
            data = data_excel[data_excel['地区'] == area]
            print(data)
            data = data.groupby(['年份', '月份', '地区'])['销售额'].sum().reset_index()
            x = data['年份'].tolist()
            y = data['月份'].tolist()
            data_x = []
            for i in range(len(x)):
                data_x.append((str(x[i])+'-'+str(y[i])+'-'+str(1)).strip())
            data['新日期'] = data_x
            data['timestamp'] = pd.to_datetime(data['新日期'])
            data.index = data['timestamp']
            # print(data)

            train = data[data['年份'] <= 2020]
            train['timestamp'] = pd.to_datetime(data['新日期'])
            train.index = train['timestamp']
            import statsmodels.api as sm

            fit1 = sm.tsa.statespace.SARIMAX(train['销售额'], order=(11, 1, 2), enforce_stationarity=False,
                                             enforce_invertibility=False).fit()

            ans = fit1.forecast(3).tolist()
            print(ans)
            List.append([area, sum(ans)])
        print(List)
        data_csv = pd.DataFrame(List, columns=(['地区', '预测销售额']))
        print(data_csv.sort_values(['预测销售额'], ascending=False))


     # 分类
    def Kind():
        data_kind = data_excel['服务分类'].drop_duplicates().tolist()
        # print(data_kind)
        List = []
        for kind in data_kind[:2]:
            data = data_excel[data_excel['服务分类'] == kind]
            # print(data)
            data = data.groupby(['年份', '月份', '服务分类'])['销售额'].sum().reset_index()
            # print(data)
            x = data['年份'].tolist()
            # print(x)
            y = data['月份'].tolist()
            # print(y)
            data_x = []
            for i in range(len(x)):
                data_x.append((str(x[i]) + '-' + str(y[i]) + '-' + str(1)).strip())
            data['新日期'] = data_x
            # print(data)
            # data_y = data['销售额'].tolist()
            # # print(data_y)
            #
            data['timestamp'] = pd.to_datetime(data['新日期'])
            data.index = data['timestamp']
            # print(data)

            train = data[data['年份'] <= 2020]
            train['timestamp'] = pd.to_datetime(data['新日期'])
            train.index = train['timestamp']


            # test = pd.DataFrame()
            # test['销售额'] = []
            # test['timestamp'] = ['2020-1-1', '2020-2-1', '2020-3-1']
            # test.index = test['timestamp']


            # print(test)
            # train['销售额'].plot(figsize=(10,6), title = '{}-train'.format(kind), fontsize=14)
            # test['销售额'].plot(figsize=(10,6), title = '{}-test'.format(kind), fontsize=14)
            # plt.show()

            import statsmodels.api as sm
            # y_hat_avg = test.copy()

            fit1 = sm.tsa.statespace.SARIMAX(train['销售额'], order=(11,1,2), enforce_stationarity=False, enforce_invertibility=False).fit()
            # print(fit1.forecast(3))

            # y_hat_avg['SARIMA'] = fit1.predict(start = "2021-01-01", end = "2021-03-01", dynamic = True)

            # plt.figure(figsize=(10, 6))
            # plt.plot(train['销售额'],label ='TRAIN')
            # plt.plot(y_hat_avg['SARIMA'],label='SARIMA')
            # plt.legend(loc='best')

            # print(y_hat_avg['SARIMA'])

            # plt.show()
            ans = fit1.forecast(3).tolist()
            print(ans)
            List.append([kind, sum(ans)])
        print(List)
        data_csv = pd.DataFrame(List, columns=(['分类', '预测销售额']))
        print(data_csv.sort_values(['预测销售额'], ascending=False))

    # Con()
    # Area()
    Kind()
    # 分类

if __name__ == "__main__":
    # task1_3()
    task1_4()


















