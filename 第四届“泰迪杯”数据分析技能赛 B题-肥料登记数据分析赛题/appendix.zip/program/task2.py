import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def task2_1():
    data_excl = pd.read_excel(r"E:\2021泰迪杯A\非洲通讯产品销售数据.xlsx", sheet_name='SalesData')
    # print(data_excl[data_excl['国家'] == 'Botswana']['利润'])
    # print(data_excl[data_excl['利润'] == 0])
    data_con = data_excl['国家'].drop_duplicates().tolist()
    # print(data_con)
    # print(len(data_con))
    data = pd.DataFrame(data_con)
    # data['国家'] = data_con
    # print(data)

    List = []
    List_2 = []
    for i in data_con:
        sales = data_excl[data_excl['国家'] == i]['销售额'].sum()
        profit = data_excl[data_excl['国家'] == i]['利润'].sum()
        List.append([i, sales, profit])
        # sales_2 = decimal.Decimal(sales).quantize(decimal.Decimal("0.00"))
        # profit_2 = decimal.Decimal(profit).quantize(decimal.Decimal("0.00"))
        # List_2.append(({i:(sales_2, profit_2)}))

        # decimal.Decimal("0.645").quantize(decimal.Decimal("0.00"))
    print(List)
    # for i in List:
        # print(i.keys())
        # print(i.values())
        # for j, k in i.items():
        #     # print(j)
        #     print(k)
        #     print(k[0])
    data = pd.DataFrame(List, columns=['国家', '销售额', '利润'])
    print(data)
    data.to_csv(r"E:\2021泰迪杯A\task2_1.csv", encoding='gbk')


SalesData = pd.read_excel('./非洲通讯产品销售数据.xlsx', sheet_name='SalesData')

SalesData['月份'] = pd.to_datetime(SalesData['日期']).dt.month
SalesData['年份'] = pd.to_datetime(SalesData['日期']).dt.year

country_list = np.unique(SalesData['国家'])

service_list = list(np.unique(SalesData['服务分类']))
def country(name):
    return SalesData.loc[SalesData['国家'] == name]

def year(data, year):
    return data.loc[data['年份'] == year]

def month2(data, year):
    new = data.loc[4<=data['月份']]
    return new.loc[new['月份']<=6]

def month3(data, year):
    new = data.loc[7<=data['月份']]
    return new.loc[new['月份']<=9]

def month4(data, year):
    new = data.loc[10<=data['月份']]
    return new.loc[new['月份']<=12]


def service(data, service):
    return data.loc[data['服务分类'] == service]

def concat_():
    j=0
    for i in range(len(country_list)):
        if i == 0:
            j+=1
            con1 = month1(year(country(country_list[i]), 2017), 2017)
        else:
            data = month1(year(country(country_list[i]), 2017+j), 2017+j)
            con1 = pd.concat([con1, data])
            j+=1
            if j>3 :
                j=0
    for i in range(len(country_list)):
        if i == 0:
            j+=1
            con2 = month2(year(country(country_list[i]), 2017), 2017)
        else:
            data = month2(year(country(country_list[i]), 2017+j), 2017+j)
            con2 = pd.concat([con2, data])
            j+=1
            if j>3 :
                j=0
    for i in range(len(country_list)):
        if i == 0:
            j+=1
            con3 = month3(year(country(country_list[i]), 2017), 2017)
        else:
            data = month3(year(country(country_list[i]), 2017+j), 2017+j)
            con3 = pd.concat([con3, data])
            j+=1
            if j>3 :
                j=0
    for i in range(len(country_list)):
        if i == 0:
            j+=1
            con4 = month4(year(country(country_list[i]), 2017), 2017)
        else:
            data = month4(year(country(country_list[i]), 2017+j), 2017+j)
            con4 = pd.concat([con4, data])
            j+=1
            if j>3 :
                j=0
    return con1,con2,con3,con4

con1,con2,con3,con4 = concat_()

def complete(name, service_, year_):
    data = country(name)
    dict1={}
    month_1 = month1(year(data,year_),year_)
    month_2 = month2(year(data,year_),year_)
    month_3 = month3(year(data,year_),year_)
    month_4 = month4(year(data,year_),year_)
    # 上一年
    month_1_1 = month1(year(data,year_-1), year_-1)
    month_2_2 = month2(year(data,year_-1), year_-1)
    month_3_3 = month3(year(data,year_-1), year_-1)
    month_4_4 = month4(year(data,year_-1), year_-1)
    if service_ in list(month_1['服务分类']) and service_ in list(month_1_1['服务分类']):
        dict1[str(name)+"_国家"+str(year_)+"第一季度_"+service_] = (sum(list(service(month_1, service_)['销售额'])) - sum(list(service(month_1_1, service_)['销售额'])))/sum(list(service(month_1_1, service_)['销售额']))
    if service_ in list(month_2['服务分类']) and service_ in list(month_2_2['服务分类']):
        dict1[str(name)+"_国家"+str(year_)+"第二季度_"+service_] = (sum(list(service(month_2, service_)['销售额'])) - sum(list(service(month_2_2, service_)['销售额'])))/sum(list(service(month_2_2, service_)['销售额']))
    if service_ in list(month_3['服务分类']) and service_ in list(month_3_3['服务分类']):
        dict1[str(name)+"_国家"+str(year_)+"第三季度_"+service_] = (sum(list(service(month_3, service_)['销售额'])) - sum(list(service(month_3_3, service_)['销售额'])))/sum(list(service(month_3_3, service_)['销售额']))
    if service_ in list(month_4['服务分类']) and service_ in list(month_4_4['服务分类']):
        dict1[str(name)+"_国家"+str(year_)+"第四季度_"+service_] = (sum(list(service(month_4, service_)['销售额'])) - sum(list(service(month_4_4, service_)['销售额'])))/sum(list(service(month_4_4, service_)['销售额']))
    return dict1

def complete1(name, service_, year_):
    data = country(name)
    dict1={}
    month_1 = month1(year(data,year_),year_)
    month_2 = month2(year(data,year_),year_)
    month_3 = month3(year(data,year_),year_)
    month_4 = month4(year(data,year_),year_)
    # 上一年
    month_1_1 = month1(year(data,year_-1), year_-1)
    month_2_2 = month2(year(data,year_-1), year_-1)
    month_3_3 = month3(year(data,year_-1), year_-1)
    month_4_4 = month4(year(data,year_-1), year_-1)
    if service_ in list(month_1['服务分类']) and service_ in list(month_1_1['服务分类']) and sum(list(service(month_1_1, service_)['利润']))!=0:
        dict1[str(name)+"_国家"+str(year_)+"第一季度_"+service_] = (sum(list(service(month_1, service_)['利润'])) - sum(list(service(month_1_1, service_)['利润'])))/sum(list(service(month_1_1, service_)['利润']))
    if service_ in list(month_2['服务分类']) and service_ in list(month_2_2['服务分类']) and sum(list(service(month_2_2, service_)['利润']))!=0:
        dict1[str(name)+"_国家"+str(year_)+"第二季度_"+service_] = (sum(list(service(month_2, service_)['利润'])) - sum(list(service(month_2_2, service_)['利润'])))/sum(list(service(month_2_2, service_)['利润']))
    if service_ in list(month_3['服务分类']) and service_ in list(month_3_3['服务分类']) and sum(list(service(month_3_3, service_)['利润']))!=0:
        dict1[str(name)+"_国家"+str(year_)+"第三季度_"+service_] = (sum(list(service(month_3, service_)['利润'])) - sum(list(service(month_3_3, service_)['利润'])))/sum(list(service(month_3_3, service_)['利润']))
    if service_ in list(month_4['服务分类']) and service_ in list(month_4_4['服务分类']) and sum(list(service(month_4_4, service_)['利润']))!=0:
        dict1[str(name)+"_国家"+str(year_)+"第四季度_"+service_] = (sum(list(service(month_4, service_)['利润'])) - sum(list(service(month_4_4, service_)['利润'])))/sum(list(service(month_4_4, service_)['利润']))
    return dict1

def concat_1(year_):
    for j in range(len(service_list)):
        if j == 0:
            for i in range(len(country_list)):
                if i == 0:
                    con1 = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                    con1 = pd.concat([con1,data])
        if j == 1:
            for i in range(len(country_list)):
                if i == 0:
                    con2 = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                    con2 = pd.concat([con2,data])
        if j == 2:
            for i in range(len(country_list)):
                if i == 0:
                    con3 = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"销售额同比增长率"])
                    con3 = pd.concat([con3,data])
    return con1,con2,con3

def concat_2(year_):
    for j in range(len(service_list)):
        if j == 0:
            for i in range(len(country_list)):
                if i == 0:
                    con1 = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                    con1 = pd.concat([con1,data])
        if j == 1:
            for i in range(len(country_list)):
                if i == 0:
                    con2 = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                    con2 = pd.concat([con2,data])
        if j == 2:
            for i in range(len(country_list)):
                if i == 0:
                    con3 = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                else:
                    data = pd.DataFrame(complete(country_list[i],service_list[j],year_),index=[str(country_list[i])+"_"+service_list[j]+"利润同比增长率"])
                    con3 = pd.concat([con3,data])
    return con1,con2,con3

con1.to_csv('F:\\Commercial各个季度销售额同比增长率.csv',encoding="gbk")
con2.to_csv('F:\\Public各个季度销售额同比增长率.csv',encoding="gbk")
con3.to_csv('F:\\Residential各个季度销售额同比增长率.csv',encoding="gbk")

con1_1.to_csv('F:\\Commercial各个季度利润同比增长率.csv',encoding="gbk")
con2_2.to_csv('F:\\Public各个季度利润同比增长率.csv',encoding="gbk")
con3_3.to_csv('F:\\Residential各个季度利润同比增长率.csv',encoding="gbk")

import pandas as pd
import decimal
decimal.getcontext().rounding = "ROUND_HALF_UP"



def task2_3():
    data_excel = pd.read_excel(r"E:\2021泰迪杯A\非洲通讯产品销售数据.xlsx", sheet_name='SalesData')
    data_excel['日期'] = pd.to_datetime(data_excel['日期'], format='%Y/%m/%d')
    data_excel['年份'] = pd.to_datetime(data_excel['日期']).dt.year
    data_excel['月份'] = pd.to_datetime(data_excel['日期']).dt.month

    data_area = data_excel['地区'].drop_duplicates().tolist()
    print(data_area)
    data_kind = data_excel['服务分类'].drop_duplicates().tolist()
    print(data_kind)
    data_con = data_excel['国家'].drop_duplicates().tolist()
    print(data_con)

    # List = []
    #
    # for area in data_area:
    #     for kind in data_kind:
    #         data = data_excel[(data_excel['地区'] == area) & (data_excel['服务分类'] == kind)].reset_index()
    #         # data = data_1[data_1['国家'] == con].reset_index()
    #         # print(data_1)
    #         print('地区 服务分类')
    #         print(area, kind)
    #
    #         data = data.groupby(['年份', '月份', '地区','服务分类'])['销售额'].sum().reset_index()
    #         x = data['年份'].tolist()
    #         y = data['月份'].tolist()
    #         data_x = []
    #         for i in range(len(x)):
    #             data_x.append((str(x[i]) + '-' + str(y[i]) + '-' + str(1)).strip())
    #         data['新日期'] = data_x
    #         data['timestamp'] = pd.to_datetime(data['新日期'])
    #         data.index = data['timestamp']
    #         # print(data)
    #
    #         train = data[data['年份'] <= 2020]
    #         train['timestamp'] = pd.to_datetime(data['新日期'])
    #         train.index = train['timestamp']
    #
    #         import statsmodels.api as sm
    #         fit1 = sm.tsa.statespace.SARIMAX(train['销售额'], order=(11, 1, 2), enforce_stationarity=False,
    #                                          enforce_invertibility=False).fit()
    #         ans = fit1.forecast(3).tolist()
    #         print(ans)
    #         List.append([area, kind, sum(ans)])
    # print(List)
    # data_csv = pd.DataFrame(List, columns=(['地区','服务分类','预测销售额']))
    # print(data_csv.sort_values(['预测销售额'], ascending=False))
    # data_csv.to_csv(r"E:\2021泰迪杯A\task2_3_销售额.csv", encoding='gbk')

    List = []
    for area in data_area:
        for kind in data_kind:
            data = data_excel[(data_excel['地区'] == area) & (data_excel['服务分类'] == kind)].reset_index()
            # data = data_1[data_1['国家'] == con].reset_index()
            # print(data_1)
            print('地区 服务分类')
            print(area, kind)

            data = data.groupby(['年份', '月份', '地区','服务分类'])['利润'].sum().reset_index()
            x = data['年份'].tolist()
            y = data['月份'].tolist()
            data_x = []
            for i in range(len(x)):
                data_x.append((str(x[i]) + '-' + str(y[i]) + '-' + str(1)).strip())
            data['新日期'] = data_x
            data['timestamp'] = pd.to_datetime(data['新日期'])
            data.index = data['timestamp']
            # print(data)

            train = data[data['年份'] <= 2020]
            train['timestamp'] = pd.to_datetime(data['新日期'])
            train.index = train['timestamp']

            import statsmodels.api as sm
            fit1 = sm.tsa.statespace.SARIMAX(train['利润'], order=(11, 1, 2), enforce_stationarity=False,
                                             enforce_invertibility=False).fit()
            ans = fit1.forecast(3).tolist()
            print(ans)
            List.append([area, kind, sum(ans)])
    print(List)
    data_csv = pd.DataFrame(List, columns=(['地区','服务分类','预测利润']))
    print(data_csv.sort_values(['预测利润'], ascending=False))
    data_csv.to_csv(r"E:\2021泰迪杯A\task2_3_利润.csv", encoding='gbk')

def task2_4():
    data_excel = pd.read_excel(r"E:\2021泰迪杯A\非洲通讯产品销售数据.xlsx", sheet_name='SalespersonData')
    data_excel = data_excel.drop(['Unnamed: 5', '备注：本表格中“销售合同”为“已成交合同”。'], axis = 1)
    # print(data_excel.info())
    name = data_excel['销售经理'].tolist()
    print(name)
    List = []
    for i in name:
        x = data_excel[data_excel['销售经理'] == i]['销售合同'].sum()
        List.append([i, x])
    data = pd.DataFrame(List, columns=['销售经理', '合同数']).sort_values('合同数', ascending=False).drop_duplicates()
    print(data)
    data.to_csv(r"E:\2021泰迪杯A\task2_4.csv", encoding='gbk')


def task2_5():
    data_excel = pd.read_excel(r"E:\2021泰迪杯A\非洲通讯产品销售数据.xlsx", sheet_name='SalesData')
    data_con = data_excel['国家'].drop_duplicates().tolist()
    # print(len(data_con))

    List = []
    for i in data_con:
        x = data_excel[data_excel['国家'] == i]['销售额'].sum()
        List.append([i, x])
    print(List)
    data = pd.DataFrame(List, columns=['国家', '销售额']).sort_values('销售额')
    print(data)
    data.to_csv(r"E:\2021泰迪杯A\task2_5.csv", encoding='gbk')

if __name__ == "__main__":
    # task2_1()
    task2_3()
    # task2_4()
    # task2_5()





























